<?php 
require_once 'reader.php'; // ExcelFile($filename, $encoding); $data = new Spreadsheet_Excel_Reader(); // Set output Encoding. $data->setOutputEncoding('gbk'); 
//”data.xls”是指要导入到mysql中的excel文件 
$data->read('data.xls'); 
require("db_config.php");
$db = mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or 
die("Could not connect to database.");//连接数据库 
mysql_query("set names 'utf8_general_ci'");//输出中文 
mysql_select_db($mysql_database,$conn) or die("can't open db:$mysql_database");
//mysql_select_db('1'); //选择数据库 
//error_reporting(E_ALL ^ E_NOTICE); 
for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) { 
																		//以下注释的for循环打印excel表数据 
																		/* 
																		for ($j = 1; $j < = $data->sheets[0]['numCols']; $j++) { 
																		echo "\"".$data->sheets[0]['cells'][$i][$j]."\","; 
																		} 
																		echo "\n"; 
																		*/ 
																		//以下代码是将excel表数据【3个字段】插入到mysql中， 
根据你的excel表字段的多少，改写以下代码吧！ 
//$sql = "INSERT INTO new3 VALUES('百度','https://www.baidu.com/','4','CN')";//'".$data->sheets[0]['cells'][$i][1]."','". $data->sheets[0]['cells'][$i][2]."','". $data->sheets[0]['cells'][$i][3]."','". $data->sheets[0]['cells'][$i][4]."','". $data->sheets[0]['cells'][$i][5]."','". $data->sheets[0]['cells'][$i][6]."','". $data->sheets[0]['cells'][$i][7]."','". $data->sheets[0]['cells'][$i][8]."','". $data->sheets[0]['cells'][$i][9]."','". $data->sheets[0]['cells'][$i][10]."','". $data->sheets[0]['cells'][$i][11]."')"; 
//echo $sql.'< br />'; 
$res = mysql_query("INSERT INTO new3 VALUES('百度','https://www.baidu.com/','4','CN')"); 
} 
?> 