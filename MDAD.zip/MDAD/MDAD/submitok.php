<?php 
error_reporting(E_ALL^E_NOTICE^E_WARNING);
require("safe.php");
require("db_config.php");

$conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting"); 
mysql_query("set names 'utf8'"); 
mysql_select_db($mysql_database,$conn) or die("can't open db:$mysql_database");

//$submitTarget=safevalue($_POST["submitTarget"]);
$submitDrug=safevalue($_POST["submitDrug"]);
$submitMicrobe=safevalue($_POST["submitMicrobe"]);
$submitReferencePubmedID=safevalue($_POST["submitReferencePubmedID"]);
$Moreintroduction=safevalue($_POST["Moreintroduction"]);
$e_mail=safevalue($_POST["e_mail"]);

//echo $_POST["Submit"];

if($_POST["Submit"]=="提交"){
$query=mysql_query("INSERT INTO submit (submitDrug,submitMicrobe,ReferencePubMedID,Moreintroduction,email)
VALUES('".$submitDrug."','".$submitMicrobe."','".$submitReferencePubmedID."','".$Moreintroduction."','".$e_mail."')");//submitTarget,'".$submitTarget."',
	error_reporting(0);
	require_once "email.class.php";
	//******************** 配置信息 ********************************
	$smtpserver = "smtp.163.com";//SMTP服务器
	$smtpserverport =25;//SMTP服务器端口
	$smtpusermail = "13813283079@163.com";//SMTP服务器的用户邮箱
	
	$smtpemailto = "502616910@qq.com";//xingchen@cumt.edu.cn发送给谁$_POST['toemail']502616910@qq.com
	
	$smtpuser = "13813283079";//SMTP服务器的用户帐号
	$smtppass = "";//SMTP服务器的用户密码
	$mailtitle = "MDAD NEW Submition of MDTD";//邮件主题$_POST['title']
	$mailcontent = "<h1>ncRNA:".$submitTarget."<br>
	Drug:".$submitDrug."<br>
	Microbe:".$submitMicrobe."<br>
	Reference PubMed ID:".$submitReferencePubmedID."<br>
	Introduction:".$Moreintroduction."<br>
	email:".$e_mail."<br>
	
	</h1>";//邮件内容
	$mailtype = "HTML";//邮件格式（HTML/TXT）,TXT为文本邮件
	//************************ 配置信息 ****************************
	$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);//这里面的一个true是表示使用身份验证,否则不使用身份验证.
	$smtp->debug = false;//是否显示发送的调试信息
	$state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailtitle, $mailcontent, $mailtype);
}
if($query){
echo "SUCCESS!THANK YOU VERY MUCH!";
}else{echo "FALSE!!";};
mysql_close($conn);
?>