<?php
header("Content-Type:text/html;charset=utf-8");
require("db_config.php");

$j=array();
$k=array();
?>
<!DOCTYPE html>
<html>
<head> 
	<meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=9;IE=8;IE=7;IE=EDGE" />
	
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Microbe-Drug Association Database</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="http://libs.baidu.com/jquery/1.10.2/jquery.min.js"></script>
	<link rel="stylesheet" href="http://static.runoob.com/assets/js/jquery-treeview/jquery.treeview.css" />
	<link rel="stylesheet" href="http://static.runoob.com/assets/js/jquery-treeview/screen.css" />
    <script src="js/bootstrap.min.js"></script>
	<script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="http://static.runoob.com/assets/js/jquery-treeview/jquery.cookie.js"></script>
	<script src="http://static.runoob.com/assets/js/jquery-treeview/jquery.treeview.js" type="text/javascript"></script>

	<script type="text/javascript">
	$(document).ready(function(){
		$("#browser").treeview({
			toggle: function() {
				console.log("%s was toggled.", $(this).find(">span").text());
			}
		});
	});
	</script>

<script type="text/javascript">
function showtree(kind)
{
  var xmlhttp;    
  /* if (str=="")
  {
    document.getElementById("txtHint").innerHTML="";
    return;
  }*/
  if (window.XMLHttpRequest)
  {
    // IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
    xmlhttp=new XMLHttpRequest();
  }
  else 
  {
    // IE6, IE5 浏览器执行代码
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById(kind).innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","./showtree.php?id="+kind,true);
  xmlhttp.send();
}
</script>
	
</head>
	<script language="javascript">
function checkemail(email){
	var str=email;
	var Expression=/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/; 
	var objExp=new RegExp(Expression);
	if(objExp.test(str)==true){
		return true;
	}else{
		return false;
	}
}	
</script>
  <body onload="showtree('Drug');showtree('Microbe');">
	<div class="contain" style="margin:10px;">
		<!--<div class="jumbotron"> 
			<h2 align="center"> <B>Microbe-Drug Association Database</B></h2>showtree('Target')-->
			
			<div style="background-image: url(MDTD.jpg);">
			<h6><Br> </h6>
			<h1 style="font-size:45px" align="center"> <B><font color="red">M</font>icrobe-<font color="red">D</font>rug <font color="red">A</font>ssociation <font color="red">D</font>atabase</B></h1>
			<h6><Br> </h6>
			</div>
			
			<div class="contain" style="margin:10px;">
				<div class="row" style="margin:10px;">
					<div class="span12" style="margin:10px;">
						<div class="tabbable" style="margin:10px;" id="tabs-534016">
							<ul class="nav nav-tabs">
								<li class="active">
									<a href="#panel-1" data-toggle="tab"><font size="5">Home</font></a>
								</li>
								<li>
									<a href="#panel-2" data-toggle="tab"><font size="5">Browse</font></a>
								</li>
								<li>
									<a href="#panel-3" data-toggle="tab"><font size="5">Search</font></a>
								</li>
								<li>
									<a href="#panel-4" data-toggle="tab"><font size="5">Submit</font></a>
								</li>
								<li>
									<a href="#panel-6" data-toggle="tab"><font size="5">Download</font></a>
								</li>
								<li>
									<a href="#panel-5" data-toggle="tab"><font size="5">Help</font></a>
								</li>
							</ul>
							<div class="tab-content">
								<div class="tab-pane active" id="panel-1">
								
								<div class="row-fluid" style="text-align:justify; text-justify:inter-ideograph;">
									
									<div class="col-sm-7">
										<h3 style="text-align:center">
											<strong>Welcome to Microbe-Drug Association Database</strong>
										</h3>
										<p class="MsoNormal">
											<span>The human microbiome is a diverse and complex community, which has an essential role in the maintenance of health state of its host. The imbalance of microorganism links many diseases such as diabetes, obesity, and IBD, making microbes an important class of drug targets. MDAD (the Microbe-Drug Association Database) is a special database that curated clinically or experimentally supported evidence for microbes as drug targets from present database including DrugBank, DCDB, PharmacoMicrobiomics, aBiofilm and publications. Each entry in MDAD has six items; they are drug name, drug molecular form, microbe name, strain name, target name, and the reference PubMed ID. In addition, the MDAD also provides related links of drug, target and publication.</span>
											
										</p>
										<p class="MsoNormal">
										</p>
										<p class="MsoNormal">
											<span>Currently, users can</span>
											
										</p>
										<p class="MsoNormal">
										</p>
										<p class="MsoListParagraph">
											<span>● browse the clinically or experimentally supported microbess as drug targets association data;</span>
											
										</p>
										<p class="MsoListParagraph">
											<span>● search the clinically or experimentally supported microbes as drug targets association data;</span>
											
										</p>
										<p class="MsoListParagraph">
											<span>● download data in the database;</span>
											
										</p>
										<p class="MsoListParagraph">
											<span>● submit new entries to the Microbe-Drug Association Database.</span>
											
										</p>
										<p class="MsoListParagraph">
										</p>
										<p class="MsoNormal">
											<span>In the future, the Microbe-Drug Association Database will</span>
											
										</p>
										<p class="MsoNormal">
										</p>
										<p class="MsoListParagraph">
											<span>● be updated timely;</span>
											
										</p>
										<p class="MsoListParagraph">
											<span>● develop tool for predicting novel associations of microbes as drug targets.</span>
											
										</p>
										<p class="MsoListParagraph">
										</p>
									</div>
									<div class="col-sm-5">
										<p class="MsoNormal">
											<strong><span>Statistics:</span></strong>
											
										</p>
										<p class="MsoNormal">
											<span>Currently, MDAD collected 5055 entries that include 1388 drugs and 180 microbes related to 993 papers.</span>
											
										</p>
										<p class="MsoNormal">
										</p>
										<p class="MsoNormal">
											<strong><span>History:</span></strong>
											
										</p>
										<p>October, 2018, the MDAD was updated with improvements. 
										</p>
										<p>May, 2018, the MDAD was updated with new entries and improvements. 
										</p>
										<p>May, 2017, the original MDAD database was released. 
										</p>
										<p class="MsoNormal">
										</p>
										<p class="MsoNormal">
											<strong><span>Contact us:</span></strong>
											
										</p>
										
										<p>
												Xing Chen
											</p>
											<p>
												Professor
											</p>
											<p>
												Director of Institute of Bioinformatics, China University of Mining and Technology
											</p>
											<p>
												School of Information and Control Engineering, China University of Mining and Technology
											</p>
											<p>
												Address: No.1,Daxue Road, Xuzhou, Jiangsu, 221116, P.R.China
											</p>
											<p>
												Email：<font color="blue">xingchen@cumt.edu.cn</font>
											</p>
											<p style="text-align:left">
												Homepage (English): <a href="http://www.researchgate.net/profile/Xing_Chen40/publications">http://www.researchgate.net/profile/Xing_Chen40/publications</a>
											</p>
											<p style="text-align:left">
												Homepage (Chinese): <a href="http://www.escience.cn/people/xingchen">http://www.escience.cn/people/xingchen</a>
											</p>
											<p style="text-align:left">
												Chen Group (Chinese): <a href="http://www.escience.cn/people/chengroup/index.html">http://www.escience.cn/people/chengroup/index.html</a>
											</p>
									</div>
								</div>
							
								</div>
								<div class="tab-pane" id="panel-2">
									<div>
										<div class="row">
											<div>
												<div class="row">
													<div style="height:600px; overflow: auto;" class="col-sm-3">
														<ul id="browser" class="filetree treeview-famfamfam">
															<li><span class="folder">All Data</span>
																<ul>
																	<li class="closed"><span class="folder">Microbe</span>
																		<ul>
																			<div id="Microbe"></div>
																		</ul>
																	</li>
																	<li class="closed"><span class="folder">Drug</span>
																		<ul>
																			<div id="Drug"></div>
																		</ul>
																	</li>
																	<!--<li class="closed"><span class="folder">Target</span>
																		<ul>
																			<div id="Target"></div>
																		</ul>
																	</li>-->
																</ul>
															</li>
														</ul>
													</div>
													<div id="testdiv" class="col-sm-9" >
													<p>Result</p>
													<iframe src="" name="view_frame" style="width:100%; height:800px;" frameborder="0"></iframe><!---->
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane"  id="panel-3"><!--style="margin:30px;"-->
									<div class="row">
										<p style="margin:10px; font-size:8;">You can search the entries by such keywords:</p>
										<form class="form-inline" role="form" action="search.php" target="search_result" method="post">
											<div class="form-group" style="margin:20px;">
												<div class="dropdown">
													<select class="form-control" name="selection" method="post"><!-- name="bmon" style="width:150px;" -->
														
														<option value="Microbe">Microbe</option>
														<option value="Drug">Drug</option>
														<option value="PubMedID">PubMed ID</option>
														
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="sr-only" for="exampleInputPassword2"></label>
												<input class="form-control input-medium search-query" type="text" name="searchword"  placeholder="Please input keywords">
											
											<input type="submit" value="Search" class="btn btn-info btn-lg" "></input>
											<!--<button type="submit" value="Search" class="btn btn-info btn-lg" onclick="search()">Search</button>onclick="search(searchword.value)-->
											<button type="reset" id="resetsearch" value="Reset all" class="btn btn-warning btn-lg">Reset ALL</button>
											</div>
											
										</form>
										<div class="col-sm-12">
											<iframe src="" id="search_result" name="search_result" style="width:100%;height:800px;" frameborder="0"></iframe>
										</div>
									</div>
								</div>
								<div class="tab-pane" id="panel-4">
<script language="javascript">
function check(form1){
	if(form1.submitMicrobe.value==""){
		alert("请输入Microbe name!");form1.submitLncRNA.focus();return false;
	}
	if(form1.submitDrug.value==""){
		alert("请输入Drug name!");form1.submitPhenotype.focus();return false;
	}
	/* if(form1.submitEF.value==""){
		alert("请输入Reference PubMed ID!");form1.submitEF.focus();return false;
	} */
	if(form1.submitReferencePubmedID.value==""){
		alert("请输入Reference Pubmed ID!");form1.submitReferencePubmedID.focus();return false;
	}
	if(form1.e_mail.value==""){
		alert("请输入Email地址!");form1.e_mail.focus();return false;
	}
	if(!checkemail(form1.e_mail.value)){
		alert("您输入Email地址不正确!");form1.e_mail.focus();return false;
	}
	return true;
	
}

/* function search()
{
  var xmlhttp;    
  // if (str=="")
  // {
    // document.getElementById("txtHint").innerHTML="";
    // return;
  // }
  if (window.XMLHttpRequest)
  {
    // IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
    xmlhttp=new XMLHttpRequest();
  }
  else
  {
    // IE6, IE5 浏览器执行代码
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById("search_result").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("POST","search.php",true);
  xmlhttp.send();
} */
</script>	
									<div class="col-sm-10">
										<h2>Welcome to submit new entries to the database.</h2>
										<form role="form" name="form1" method="post" action="submitok.php" onsubmit="return check(this)">
										  <div class="form-group">
											<label for="submitDrug">Drug name (*)</label>
											<input type="text" name="submitDrug"  class="form-control" id="submitDrug" placeholder="Enter Drug name">
										  </div>
										  <div class="form-group">
											<label for="submitMicrobe"> Microbe name (*)</label>
											<input type="text" class="form-control" name="submitMicrobe" id="submitMicrobe" placeholder="Enter Microbe name">
										  </div>
										  <!--<div class="form-group">
											<label for="submitTarget"> Target name</label>
											<input type="text" class="form-control" name="submitTarget" id="submitTarget" placeholder="Enter Target name">
										  </div>-->
										  <div class="form-group">
											<label for="Reference PubMed ID">Reference PubMed ID(*)</label>
											<input type="text" class="form-control" name="submitReferencePubmedID" id="Reference PubMed ID" placeholder="Enter Reference PubMed ID">
										  </div>
										  <div class="form-group">
											<label for="YourEmaiinput">Your Email(*)</label>
											<input name="e_mail" type="text" id="e_mail2" class="form-control" placeholder="Enter Your Email">
										  </div>
										  <div class="form-group">
											<label for="Moreintroductioninput">More introduction(limited to 500 words)</label>
											<textarea class="form-control" name="Moreintroduction" rows="3" id="Moreintroductioninput"></textarea>
										  </div>
										  <button type="submit" name="Submit" value="提交"  class="btn btn-info btn-lg"><BIG>Submit</BIG></button>
										  <button type="reset" id="resetsearch" value="Reset all" class="btn btn-warning btn-lg"><BIG>Reset ALL</BIG></button>
										</form>
									</div>
									
								</div>
								<div class="tab-pane" style="margin:30px 0 0 50px; text-align:justify; text-justify:inter-ideograph;" id="panel-5">
									<div class="span12">
										<h3 style="text-align:center">
											<strong>MDAD Tutorial</strong>
										</h3>
										<h4 style="text-align:center">
											<strong>October 2, 2018</strong>
										</h4>
										<p class="MsoNormal">
											<span>The detailed usage of the database is as followings:</span>
											
										</p>
										<p class="MsoNormal">
											<strong><span>[1]</span></strong> <span>Visiting MDAD: Log on MDAD at <a href="http://chengroup.cumt.edu.cn/MDAD/"> http://chengroup.cumt.edu.cn/MDAD/</a>.</span>
											
										</p>
										<p class="MsoNormal">
											<strong><span>[2]</span></strong> <span>To browse microbes and drugs association data in the database, please click the menu "Browse" (Figure 1). For example, for the microbes and drugs association from the candidate microbes, select “microbe” (step 1) and select the one you are interested in (step 2). The result will be shown in the right panel (step 3). To browse the entries related to the candidate drug, please click “drug” and select the one you are interested in.</span>
											
										</p>
										<p style="text-align:center">
											<img width="800" height="400" src="browse1.jpg" alt='' />
											
										</p>
										<p style="text-align:center">
											<span>Figure 1. A demo for browsing data in the database</span>
											
										</p>
										<p class="MsoNormal">
											<strong><span>[3]</span></strong> <span>To search data in the database, select the menu "Search". MDAD provides functions of "search" by names of microbes, drugs and PMID of reference. Input your candidate keywords into corresponding blanks and submit the query.</span>
											
										</p>
										<p class="MsoNormal">
											<strong><span>[4]</span></strong> <span>To download data in the database, select the menu "Download". MDAD provides two formats of downloadable file in TEXT and Excel formats, respectively. The users can download all data in MDAD, including the microbe-drug association data, list of all microbes and drugs.</span>
											
										</p>
										<p class="MsoNormal">
											<strong><span>[5]</span></strong> <span>To submit new entries to the database, select the menu "Submit". The users need to input their data into corresponding blanks and then submit the query. We will further curate the submitted information to determine whether to add the new entries to the database or not.</span>
											
										</p>
										<p class="MsoNormal">
											<strong><span>[6]</span></strong> <span>Currently, all data in MDAD is free only for academic users and please contact Prof. Xing Chen for commercial using. If you used the data in MDAD, please cite “….”</span>
											
										</p>
										<p class="MsoNormal">
											<span>If there are any comments or suggestions, please contact Prof. Xing Chen at</span> <span>xingchen@amss.ac.cn</span> <span>or</span> <span>xingchen@cumt.edu.cn.</span>
										</p>
									</div>
								</div>
								<div class="tab-pane" style="margin:30px;font-size:26px" id="panel-6">
									<p>The whole dataset of disease-related microbes and drugs association data ( <a href=".\Download\all data.txt" download="all data.txt">txt</a> or <a href=".\Download\all data.xlsx" download="all data.xlsx">excel</a>).</p>
									<p>The list of microbes ( <a href=".\Download\microbes.txt" download="microbes.txt">txt</a> or <a href=".\Download\microbes.xlsx" download="microbes.xlsx">excel</a>).</p>
									<p>The list of drugs ( <a href=".\Download\drugs.txt" download="drugs.txt">txt</a> or <a href=".\Download\drugs.xlsx" download="drugs.xlsx">excel</a>).</p>
									
									</div>
							</div>
								
						</div>
					</div>
				</div>
			</div>
		
		<!--</div><p>The list of references ( <a href=".\Download\references.txt" download="references.txt">txt</a> or <a href=".\Download\references.xlsx" download="references.xlsx">excel</a>).</p>
								
		<footer>
			<p>© 2016 Chengroup. · <a href="#"></a> · <a href="#">team</a></p>
		</footer>-->
	</div>

  </body>
</html>
<?php
//mysql_close($conn);
?>