<?php
	function safevalue($data){
		if(empty($data))
		{
			return "";
		}
		$data = trim($data);
		//$data =mysql_real_escape_string($data)
		//$data = stripcslashes($data);
		//$data = htmlspecialchars($data);
		$data = str_replace("delete","",$data);
		$data = str_replace("drop","",$data);
		$data = str_replace("insert","",$data);
		return $data;
	}
?>