<!DOCTYPE html>
<html 

<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$browsetarget=$_GET["id"];//sw=searchword
require("db_config.php");				
$conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting"); 
mysql_query("set names 'utf8'"); 
mysql_select_db($mysql_database,$conn) or die("can't open db:$mysql_database");
$result=mysql_query("select * from mdtd WHERE Drug='".$browsetarget."' or Microbe='".$browsetarget."'or Strain='".$browsetarget."'or Target='".$browsetarget."' "); //LncRNA='".$browsetarget."' OR EF='".$browsetarget."' OR $sel前后不加.或引号；获得记录总数
$result1=mysql_num_rows($result);
//echo $result1;
  if($result1==0)
	echo "CAN NOT FIND";
?>

   <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=9;IE=8;IE=7;IE=EDGE">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!--<style type="text/css">
        table
        {
            table-layout:fixed;
            width:100%;
        }
        td{white-space:nowrap;overflow:hidden}
    </style>-->
  </head> 
<script language="javascript">
  /*双击获取文本信息
  */
  window.onload=function(){ 
       var table1=document.getElementById("table1");
  var td1=table1.getElementsByTagName("td");
  for( i=0,j=td1.length;i<j;i++){  
      td1[i].ondblclick=function(){
  alert(this.innerText);}
  }
  }
</script>
  <body>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) 
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed 
    <script src="js/bootstrap.min.js"></script>-->
	
	<div class="container-fluid">
      <div class="row">
		<div class="col-sm-12 col-md-12 main">
          <div ><!--class="table-responsive"-->
            <table id="table1" border="1" width="100%"><!--class="table table-striped" style="text-align:left; margin:1px;"-->
              <thead>
                <tr>
                  <th>NO.</th>
                  <th width="100" style="text-align:center;">Drug</th>
				  <th style="text-align:center;">Molecular form</th>
                  <th width="90">DrugBank ID</th>
				  <th style="text-align:center;">Microbe</th>
				  <th style="text-align:center;">Strain</th>
				  <th style="text-align:center;">Target</th>
				  <th width="80">Uniprot ID</th>
				  <th width="80">PubMed ID</th>
				  
                </tr>
              </thead>
				<tbody ><!--style="text-align:center;"-->
				<?php
				  $i=1;
					while($row = mysql_fetch_array($result))
					{
				?>
                <tr>
                  <td><?php echo $i++;?></td>
                  <td style="width:100px"><a href="browse.php?id=<?php echo $row["Drug"];?>"><?php echo $row["Drug"];?></a></td>
				  <td width="auto"><?php echo $row["Molecularform"];?></td>
				  <td style="text-align:center;"><a href="<?php echo $row["DrugBankLink"];?>" target="_black"><?php echo $row["DrugBankID"];?></a></td>
				  <td><a href="browse.php?id=<?php echo $row["Microbe"];?>"><?php echo $row["Microbe"];?></a></td>
				  <td><?php echo $row["Strain"];?></td>
				  <td><?php echo $row["Target"];?></td>
				  <td style="text-align:center;"><a href="<?php echo $row["Uniprotlink"];?>" target="_black"><?php echo $row["UniprotID"];?></a></td>
				  <td style="text-align:center;"><a a href="https://www.ncbi.nlm.nih.gov/pubmed/?term=<?php echo $row["PubMedID"];?>" target="_black""><?php echo $row["PubMedID"];?></a></td>  
				  
				</tr>
<?php } mysql_close($conn);?>
				</tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>