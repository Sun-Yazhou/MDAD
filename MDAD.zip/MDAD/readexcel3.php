﻿<?php
set_time_limit(0);
require("db_config.php");
require_once './PHPExcel/Classes/PHPExcel.php';
$conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting"); 
mysql_query("set names 'utf8'");
mysql_select_db($mysql_database,$conn) or die("can't open db:$mysql_database");
echo '<p>TEST PHPExcel 1.8.0: read xlsx file</p>';
$filename = "01.xls";
$objReader = PHPExcel_IOFactory::createReaderForFile($filename); 
$objPHPExcel = $objReader->load($filename);
$objPHPExcel->setActiveSheetIndex(0);
//$date = $objPHPExcel->getActiveSheet()->getCell('A10')->getValue();
//echo $date;
$objWorksheet = $objPHPExcel->getActiveSheet();
/*
$highestRow = $objWorksheet->getHighestRow();
$highestColumm = $objWorksheet->getHighestColumn(); // 取得总列数
echo $highestColumm;
for ($row = 2; $row <= $highestRow; $row++){//行数是以第1行开始
	for ($column = 0; $column <= $highestColumm; $column++) {//列数是以第0列开始
		$columnName = PHPExcel_Cell::stringFromColumnIndex($column);
		echo $column ;
		//echo "<p>".$columnName.$row.":".$objWorksheet->getCellByColumnAndRow($column, $row)->getValue()."</p>";
	}
}
*/


foreach($objWorksheet->getRowIterator() as $row){
	$cellIterator = $row->getCellIterator();
	$cellIterator->setIterateOnlyExistingCells(false);
	$tempcow = "";
	foreach($cellIterator as $cell){
		$str =addslashes($cell->getValue());
		$str=str_replace("′","'",$str);
		$str=str_replace(" "," ",$str);
		$str=str_replace("α","α",$str);
		$str=str_replace("β","β",$str);
		$str=trim($str," ");
		//echo($str).'</br>';
		$tempcow = $tempcow.'"'.$str.'",';
	}
	$tempcow = substr($tempcow,0,strlen($tempcow)-1);
	echo $tempcow.'</br>';
	$result=mysql_query('INSERT INTO mdtd (id,Drug,Molecularform,DrugBankID,DrugBankLink,Microbe,Strain,Target,UniprotID,Uniprotlink,PubMedID,PubMedLink)	VALUES ('.$tempcow.')');
}
mysql_close($conn);
echo "Cool HAHA"
?>