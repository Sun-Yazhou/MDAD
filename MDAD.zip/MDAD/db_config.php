<?php
//header("content-type:text/html;charset=utf-8");
$mysql_server_name='localhost:3307'; //改成自己的mysql数据库服务器
$mysql_username='root'; //改成自己的mysql数据库用户名
$mysql_password='xindian@010218'; //改成自己的mysql数据库密�?
$mysql_database='mdtd'; //数据库名

//Phpinfo();PHP版本

?>