<!DOCTYPE html>
<html>
<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING);
	$kind=$_GET["id"];//?id=  只能用GET
	require("db_config.php");
	$conn=mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("error connecting"); 
	mysql_query("set names 'utf8_general_ci'"); 
	mysql_select_db($mysql_database,$conn) or die("can't open db:$mysql_database");
	//echo $key="select distinct ",$kind," from info_info";
	$result=mysql_query("select distinct ".$kind." from mdtd ORDER BY ".$kind); //$sel前后不加.或引号；获得记录总数
	//echo $result;
	$result1=mysql_num_rows($result);
	//echo $result1;
	  if($result1==0)
		echo "CAN NOT FIND";
	  $i=1;
		while($row = mysql_fetch_array($result))
		{
	?>
	  <li><span class="file"><a href="browse.php?id=<?php echo $row["$kind"];?>" target="view_frame"><?php echo $row["$kind"];?></a></span></li>
	<?php } mysql_close($conn);
?> 
</html>