It is necessary to set up a proper environment to run the code:
1.Windows Server 2012
2.two ports available(we used 80 and 3307)
3.PHPStudy2018
Then, please find the phpstudy installation directory and move folder "MDAD" into folder "/phpstudy/WWW".
Last, please refere to http://phpstudy.php.cn/jishu-php-2956.html to run the code. The "index.php" in folder "MDAD" is the homepage.